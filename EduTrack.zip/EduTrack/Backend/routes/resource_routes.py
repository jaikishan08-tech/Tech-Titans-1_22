# backend/routes/resource_routes.py
from flask import Blueprint, jsonify, request
from app import db
from models import Resource
import os, requests

resource_bp = Blueprint('resource_bp', __name__)

YOUTUBE_API_KEY = os.getenv('YOUTUBE_API_KEY')

# Fetch from YouTube (search) and save into resources table as type=video
@resource_bp.route('/youtube/<int:grade>/<subject>', methods=['GET'])
def youtube_fetch_and_list(grade, subject):
    if not YOUTUBE_API_KEY:
        return jsonify({"message": "YOUTUBE_API_KEY not configured on server"}), 500

    # search YouTube
    query = f"Class {grade} {subject} lessons"
    url = ("https://www.googleapis.com/youtube/v3/search"
           f"?part=snippet&q={requests.utils.requote_uri(query)}&type=video&maxResults=5&key={YOUTUBE_API_KEY}")
    r = requests.get(url, timeout=10)
    if r.status_code != 200:
        return jsonify({"message": "YouTube API error", "detail": r.text}), 502

    data = r.json()
    videos = []
    for item in data.get('items', []):
        snippet = item.get('snippet', {})
        title = snippet.get('title')
        vid_id = item['id'].get('videoId')
        if not vid_id:
            continue
        link = f"https://www.youtube.com/watch?v={vid_id}"

        # avoid duplicates: check exact link
        exists = Resource.query.filter_by(link=link).first()
        if not exists:
            res = Resource(grade=grade, subject=subject, type='video', title=title, link=link)
            db.session.add(res)
            try:
                db.session.commit()
            except Exception:
                db.session.rollback()

        videos.append({"title": title, "url": link})

    return jsonify({"grade": grade, "subject": subject, "videos": videos})


# List saved resources (all types) for a grade+subject
@resource_bp.route('/list/<int:grade>/<subject>', methods=['GET'])
def list_resources(grade, subject):
    items = Resource.query.filter_by(grade=grade, subject=subject).order_by(Resource.created_at.desc()).all()
    return jsonify([r.to_dict() for r in items])


# Admin: add resource manually (video/pdf/paper/note)
@resource_bp.route('/add', methods=['POST'])
def add_resource():
    data = request.get_json() or {}
    grade = data.get('grade')
    subject = data.get('subject')
    rtype = data.get('type')  # video/pdf/paper/note
    title = data.get('title')
    link = data.get('link')

    if not all([grade, subject, rtype, title, link]):
        return jsonify({"message": "grade, subject, type, title and link are required"}), 400

    res = Resource(grade=grade, subject=subject, type=rtype, title=title, link=link)
    db.session.add(res)
    db.session.commit()
    return jsonify({"message": "Resource added", "resource": res.to_dict()}), 201

