# backend/routes/planner_routes.py
from flask import Blueprint, request, jsonify
from app import db
from models import StudyPlan, Resource, User
from datetime import date, timedelta

planner_bp = Blueprint('planner_bp', __name__)

# Simple study-plan generator (MVP)
# POST /planner/generate
# body: { "user_id": 1, "days": 14 }
@planner_bp.route('/generate', methods=['POST'])
def generate_plan():
    data = request.get_json() or {}
    user_id = data.get('user_id')
    days = int(data.get('days', 14))

    if not user_id:
        return jsonify({"message": "user_id required"}), 400

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "user not found"}), 404

    grade = user.grade or 10

    # simple subject selection by grade (expand later)
    grade_subjects = {
        10: ["Mathematics", "Science", "English"],
        9: ["Mathematics", "Science", "English"],
        8: ["Mathematics", "Science", "English"]
    }
    subjects = grade_subjects.get(grade, ["General Studies"])

    # Clear previous plan for user (MVP simple)
    StudyPlan.query.filter_by(user_id=user_id).delete()
    db.session.commit()

    plan_items = []
    # Spread study hours across subjects over 'days'
    hours_per_day = 2  # default
    for i in range(days):
        day = date.today() + timedelta(days=i)
        # rotate subjects across day
        subj = subjects[i % len(subjects)]
        topic = f"{subj} - Revision (day {i+1})"
        item = StudyPlan(user_id=user_id, subject=subj, topic=topic, hours=hours_per_day, scheduled_date=day)
        db.session.add(item)
        plan_items.append(item)

    db.session.commit()
    return jsonify({"message": "Study plan generated", "plan": [p.to_dict() for p in plan_items]}), 201


# Endpoint to fetch a user's plan
@planner_bp.route('/user/<int:user_id>', methods=['GET'])
def get_user_plan(user_id):
    plans = StudyPlan.query.filter_by(user_id=user_id).order_by(StudyPlan.scheduled_date).all()
    return jsonify([p.to_dict() for p in plans])
