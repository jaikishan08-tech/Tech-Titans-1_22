# backend/routes/__init__.py
# Marks 'routes' as a package
