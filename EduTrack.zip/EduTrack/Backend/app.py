from flask import Flask, jsonify
from routes.auth_routes import auth_bp  # ✅ import the test route

app = Flask(__name__)
app.register_blueprint(auth_bp)

@app.route('/')
def home():
    return jsonify({"message": "EduTrack backend structure is working correctly!"})

if __name__ == '__main__':
    app.run(debug=True)
